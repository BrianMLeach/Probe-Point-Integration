import sys
def execTest(pathBinary, pathDVF, pathGRD, release):

	from test.framework.launcher.main import TestLauncher

	tl = TestLauncher()
	try:
		tl.configure(
			pathBinary=pathBinary,
			connectionCommand="C:/SW-Tools/GHS_V800_RH800/6_1_4/comp_201355/850eserv2 -e1lpd4=11000 -RH850 -id ffffffffffffffffffffffff -noiop -df='%s' -dclock=16000,0,swoff -F" % pathDVF,
			runCommand="target fload srec k:\prj.hex",
			pathGRD="%s" % pathGRD,
			resultDir="C:/Users/hefesw11/PRE_NSK_CMF2_SW1_RC3/30_BSW/EcuM/Integration_Test\Functional_Tests/result",
			release=release
			)
	except TypeError:
		print("Configuration failed.")
	# Module to test.
	from Functional_Tests.module import Functional_Tests
	tl.runTest("R_AppSwc_Functional_Tests_Debug", Functional_Tests)

if __name__=="__main__":
	testerFrameworkRoot = "W:/HEFeSW11/ModeManagement_Tests/TestIntegrationAutotool"
	sys.path = [testerFrameworkRoot] + sys.path
	sys.path.append("C:/Users/hefesw11/PRE_NSK_CMF2_SW1_RC3/30_BSW/EcuM/Integration_Test")
	sys.path.append("W:/HEFeSW11/ModeManagement_Tests/TestIntegrationAutotool")
	pathBinary="C:/Users/hefesw11/PRE_NSK_CMF2_SW1_RC3/25_Build/Results/Bin/EPSProductPlatform.out"
	pathDVF="W:/HEFeSW11/Launch Multi GUI P1X/dr7f701310.dvf"
	pathGRD="W:/HEFeSW11/ModeManagement_Tests/TestIntegrationAutotool"
	release="1"

	execTest(pathBinary=pathBinary, pathDVF=pathDVF, pathGRD=pathGRD, release=release)
