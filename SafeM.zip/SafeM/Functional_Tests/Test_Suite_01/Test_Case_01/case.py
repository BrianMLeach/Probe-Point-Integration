# Test Autotool Generator v1.1.0


import time
import random

from test.framework.generic.case import TestCaseGeneric

from test.framework.generic.type import *
from test.manager import setCurrentStep

class Test_Case_01(TestCaseGeneric): 
	"""
	@requirement SPEC_SafeMng_FCT_3
	"""

	
	#=============
	# DECLARATION
	#=============
	
	
	#=============
	# ORIGIN STEP
	#=============
	def getOriginStepList(self):
		"""
		@return List of steps that originate from this TestCase (neither a Reference nor a Template).
		"""
		return ['SPEC_SafeMng_FCT_4', 'SPEC_SafeMng_FCT_5', 'SPEC_SafeMng_FCT_7', 'SPEC_SafeMng_FCT_9', 'SPEC_SafeMng_FCT_10']
	
	
	#==============
	# PRECONDITION
	#==============
	def setUp(self):
	
		#=======================
		# 01. Set BP SafeM_Init
		#=======================
		self.executeStep(ID="SPEC_SafeMng_FCT_4", fct=self.__step1_1, step=1, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01")
		
		
		
		#==============================================
		# 02. Set BP BswM_ActionList_EPSPP_AL_InitPmic
		#==============================================
		self.executeStep(ID="SPEC_SafeMng_FCT_5", fct=self.__step1_2, step=2, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01")
		
		
		
	
	def __step1_1(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_4
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_Init(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_01.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#================
		# SET BREAKPOINT
		#================
		self._setBreakpoint(breakpoint="SafeM_Init")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	def __step1_2(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_5
		Prototype of the function is defined as follows:
		STATIC FUNC(Std_ReturnType, BSWM_CODE) BswM_ActionList_EPSPP_AL_InitPmic(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_01.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#================
		# SET BREAKPOINT
		#================
		self._setBreakpoint(breakpoint="BswM_ActionList_EPSPP_AL_InitPmic")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	
	
	#======
	# TEST
	#======
	def runTest(self):
	
		#==================
		# 01. Reset board 
		#==================
		self.executeStep(ID="SPEC_SafeMng_FCT_7", fct=self.__step2_1, step=1, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01")
		
		
		
	
	def __step2_1(self):
		"""
		@brief Check that SafeM_Init is called during the execution of PMIC Initialization BswM Action List
		@requirement SPEC_SafeMng_FCT_7
		"""
	
		# List of conditions verified by this step.
		lCondition = ['Wait for Breakpoint BswM_ActionList_EPSPP_AL_InitPmic to be exited', 'Breakpoint SafeM_Init reached exactly 1 time', 'Breakpoint BswM_ActionList_EPSPP_AL_InitPmic reached before SafeM_Init']
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01", timeout=1.000000, bRemoveAfter=True)
		
	
		# Resume debugger.
		self._resumeDebugger()
	
		#=============
		# RESET BOARD
		#=============
		self._resetBoard()
	
		#========================
		# CHECK EXPECTED RESULTS
		#========================
		# Wait for Breakpoint BswM_ActionList_EPSPP_AL_InitPmic to be exited
		self._waitDebuggerExitedBreakpoint(breakpoint="BswM_ActionList_EPSPP_AL_InitPmic")
		
		# Breakpoint SafeM_Init reached exactly 1 time
		self._assertBreakpointReachedExactly(breakpoint="SafeM_Init", assertCount=1)
		
		# Breakpoint BswM_ActionList_EPSPP_AL_InitPmic reached before SafeM_Init
		self._assertBreakpointReachedBefore(breakpoint1="BswM_ActionList_EPSPP_AL_InitPmic", breakpoint2="SafeM_Init")
	
	
	
	
	#===============
	# POSTCONDITION
	#===============
	def tearDown(self):
	
		#================================================
		# 01. Unset BP BswM_ActionList_EPSPP_AL_InitPmic
		#================================================
		self.executeStep(ID="SPEC_SafeMng_FCT_9", fct=self.__step3_1, step=1, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01")
		
		
		
		#=========================
		# 02. Unset BP SafeM_Init
		#=========================
		self.executeStep(ID="SPEC_SafeMng_FCT_10", fct=self.__step3_2, step=2, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01")
		
		
		
	
	def __step3_1(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_9
		Prototype of the function is defined as follows:
		STATIC FUNC(Std_ReturnType, BSWM_CODE) BswM_ActionList_EPSPP_AL_InitPmic(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_01.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#==================
		# UNSET BREAKPOINT
		#==================
		self._removeBreakpoint(breakpoint="BswM_ActionList_EPSPP_AL_InitPmic")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	def __step3_2(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_10
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_Init(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_01.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#==================
		# UNSET BREAKPOINT
		#==================
		self._removeBreakpoint(breakpoint="SafeM_Init")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_01.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	
