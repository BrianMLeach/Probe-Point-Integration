
#define RTE_CORE

#include "test_mechanism.h"
#include "Functional_Tests_Test_Suite_01_Test_Case_01.h"

/*=============*/
/* DECLARATION */
/*=============*/

/* Notify the end of the test to the python layer. */
static FUNC(void, CtAppSwc_Debug_CODE) Test_StepFinished() { ui8CurrentStep = 0; };


/*================================*/
/* Internal functions declaration */
/*================================*/
FUNC(void, CtAppSwc_Debug_CODE) Functional_Tests_Test_Suite_01_Test_Case_01_Precondition(void);
FUNC(void, CtAppSwc_Debug_CODE) Functional_Tests_Test_Suite_01_Test_Case_01_Test(void);
FUNC(void, CtAppSwc_Debug_CODE) Functional_Tests_Test_Suite_01_Test_Case_01_Postcondition(void);

/*=======================*/
/* Parameter declaration */
/*=======================*/


/*================*/
/* TEST EXECUTION */
/*================*/
FUNC(void, CtAppSwc_Debug_CODE) Functional_Tests_Test_Suite_01_Test_Case_01(void)
{

	/* Identify the current sequence to run. */
	switch(ui8CurrentSequence)
	{
		case 1:
			Functional_Tests_Test_Suite_01_Test_Case_01_Precondition();
			break;
		case 2:
			Functional_Tests_Test_Suite_01_Test_Case_01_Test();
			break;
		case 3:
			Functional_Tests_Test_Suite_01_Test_Case_01_Postcondition();
			break;
	}

}


/*====================*/
/* SEQUENCE EXECUTION */
/*====================*/
FUNC(void, CtAppSwc_Debug_CODE) Functional_Tests_Test_Suite_01_Test_Case_01_Precondition(void)
{
	/* Increment delay step each time. */
	ui16CurrentDelayStep++;
	
	switch(ui8CurrentStep)
	{
		case 1:
			break;
		case 2:
			break;
		default: /* Do nothing. */
	}
	
	/* Reset delay step. */
	ui16CurrentDelayStep = 0;
	
	/* Step performed. */
	Test_StepFinished();

}

FUNC(void, CtAppSwc_Debug_CODE) Functional_Tests_Test_Suite_01_Test_Case_01_Test(void)
{
	/* Increment delay step each time. */
	ui16CurrentDelayStep++;
	
	switch(ui8CurrentStep)
	{
		case 1:
			break;
		default: /* Do nothing. */
	}
	
	/* Reset delay step. */
	ui16CurrentDelayStep = 0;
	
	/* Step performed. */
	Test_StepFinished();

}

FUNC(void, CtAppSwc_Debug_CODE) Functional_Tests_Test_Suite_01_Test_Case_01_Postcondition(void)
{
	/* Increment delay step each time. */
	ui16CurrentDelayStep++;
	
	switch(ui8CurrentStep)
	{
		case 1:
			break;
		case 2:
			break;
		default: /* Do nothing. */
	}
	
	/* Reset delay step. */
	ui16CurrentDelayStep = 0;
	
	/* Step performed. */
	Test_StepFinished();

}

