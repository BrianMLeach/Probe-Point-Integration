# Test Autotool Generator v1.1.0


import time
import random

from test.framework.generic.case import TestCaseGeneric

from test.framework.generic.type import *
from test.manager import setCurrentStep

class Test_Case_02(TestCaseGeneric): 
	"""
	@requirement SPEC_SafeMng_FCT_11
	"""

	
	#=============
	# DECLARATION
	#=============
	
	
	#=============
	# ORIGIN STEP
	#=============
	def getOriginStepList(self):
		"""
		@return List of steps that originate from this TestCase (neither a Reference nor a Template).
		"""
		return ['SPEC_SafeMng_FCT_12', 'SPEC_SafeMng_FCT_13', 'SPEC_SafeMng_FCT_14', 'SPEC_SafeMng_FCT_15', 'SPEC_SafeMng_FCT_16']
	
	
	#==============
	# PRECONDITION
	#==============
	def setUp(self):
	
		#=======================
		# 01. Set BP SafeM_Init
		#=======================
		self.executeStep(ID="SPEC_SafeMng_FCT_12", fct=self.__step1_1, step=1, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02")
		
		
		
		#=============================
		# 02. Set BP BswM_RequestMode
		#=============================
		self.executeStep(ID="SPEC_SafeMng_FCT_13", fct=self.__step1_2, step=2, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02")
		
		
		
	
	def __step1_1(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_12
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_Init(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_02.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#================
		# SET BREAKPOINT
		#================
		self._setBreakpoint(breakpoint="SafeM_Init")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	def __step1_2(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_13
		Prototype of the function is defined as follows:
		extern FUNC(void, BSWM_CODE) BswM_RequestMode(BswM_UserType requesting_user, BswM_ModeType requested_mode);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_02.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#================
		# SET BREAKPOINT
		#================
		self._setBreakpoint(breakpoint="BswM_RequestMode")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	
	
	#======
	# TEST
	#======
	def runTest(self):
	
		#==================
		# 01. Reset board 
		#==================
		self.executeStep(ID="SPEC_SafeMng_FCT_14", fct=self.__step2_1, step=1, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02")
		
		
		
	
	def __step2_1(self):
		"""
		@brief Check that BswM_RequestMode is called in the context of SafeM_Init execution.
		       Check that the variable that stores the internal state of SafeM is set to not initialized when BswM_RequestMode is called.
		@requirement SPEC_SafeMng_FCT_14
		"""
	
		# List of conditions verified by this step.
		lCondition = ['Wait for Breakpoint SafeM_Init to be reached', 'Breakpoint BswM_RequestMode reached exactly 0 time', 'Wait for Breakpoint BswM_RequestMode to be reached', 'SafeM_State_t == SAFEM_NOT_INITIALISED']
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		# Resume debugger.
		self._resumeDebugger()
	
		#=============
		# RESET BOARD
		#=============
		self._resetBoard()
	
		#========================
		# CHECK EXPECTED RESULTS
		#========================
		# Wait for Breakpoint SafeM_Init to be reached
		self._waitDebuggerReachedBreakpoint(breakpoint="SafeM_Init")
		
		# Breakpoint BswM_RequestMode reached exactly 0 time
		self._assertBreakpointReachedExactly(breakpoint="BswM_RequestMode", assertCount=0)
		
		# Wait for Breakpoint BswM_RequestMode to be reached
		self._waitDebuggerReachedBreakpoint(breakpoint="BswM_RequestMode")
		
		# SafeM_State_t == SAFEM_NOT_INITIALISED
		self._assertExpression("SafeM_State_t == 0")
	
	
	
	
	#===============
	# POSTCONDITION
	#===============
	def tearDown(self):
	
		#===============================
		# 01. Unset BP BswM_RequestMode
		#===============================
		self.executeStep(ID="SPEC_SafeMng_FCT_15", fct=self.__step3_1, step=1, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02")
		
		
		
		#=========================
		# 02. Unset BP SafeM_Init
		#=========================
		self.executeStep(ID="SPEC_SafeMng_FCT_16", fct=self.__step3_2, step=2, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02")
		
		
		
	
	def __step3_1(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_15
		Prototype of the function is defined as follows:
		extern FUNC(void, BSWM_CODE) BswM_RequestMode(BswM_UserType requesting_user, BswM_ModeType requested_mode);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_02.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#==================
		# UNSET BREAKPOINT
		#==================
		self._removeBreakpoint(breakpoint="BswM_RequestMode")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	def __step3_2(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_16
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_Init(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_02.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#==================
		# UNSET BREAKPOINT
		#==================
		self._removeBreakpoint(breakpoint="SafeM_Init")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_02.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	
