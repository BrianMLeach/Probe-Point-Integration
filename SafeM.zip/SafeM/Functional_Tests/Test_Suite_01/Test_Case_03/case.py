# Test Autotool Generator v1.1.0


import time
import random

from test.framework.generic.case import TestCaseGeneric

from test.framework.generic.type import *
from test.manager import setCurrentStep

class Test_Case_03(TestCaseGeneric): 
	"""
	@requirement SPEC_SafeMng_FCT_18
	"""

	
	#=============
	# DECLARATION
	#=============
	
	
	#=============
	# ORIGIN STEP
	#=============
	def getOriginStepList(self):
		"""
		@return List of steps that originate from this TestCase (neither a Reference nor a Template).
		"""
		return ['SPEC_SafeMng_FCT_26', 'SPEC_SafeMng_FCT_20', 'SPEC_SafeMng_FCT_21', 'SPEC_SafeMng_FCT_22', 'SPEC_SafeMng_FCT_27']
	
	
	#==============
	# PRECONDITION
	#==============
	def setUp(self):
	
		#=======================
		# 01. Set BP SafeM_Init
		#=======================
		self.executeStep(ID="SPEC_SafeMng_FCT_26", fct=self.__step1_1, step=1, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03")
		
		
		
		#========================================
		# 02. Set BP SafeM_StartErrorOutToggling
		#========================================
		self.executeStep(ID="SPEC_SafeMng_FCT_20", fct=self.__step1_2, step=2, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03")
		
		
		
	
	def __step1_1(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_26
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_Init(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_03.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#================
		# SET BREAKPOINT
		#================
		self._setBreakpoint(breakpoint="SafeM_Init")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	def __step1_2(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_20
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_StartErrorOutToggling(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_03.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#================
		# SET BREAKPOINT
		#================
		self._setBreakpoint(breakpoint="SafeM_StartErrorOutToggling")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	
	
	#======
	# TEST
	#======
	def runTest(self):
	
		#==================
		# 01. Reset board 
		#==================
		self.executeStep(ID="SPEC_SafeMng_FCT_21", fct=self.__step2_1, step=1, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03")
		
		
		
	
	def __step2_1(self):
		"""
		@brief Check that SafeM_StartErrorOutToggling is called in the context of SafeM_Init execution.
		@requirement SPEC_SafeMng_FCT_21
		"""
	
		# List of conditions verified by this step.
		lCondition = ['Wait for Breakpoint SafeM_Init to be exited', 'Breakpoint SafeM_StartErrorOutToggling reached exactly 1 time', 'Breakpoint SafeM_Init reached before SafeM_StartErrorOutToggling']
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03", timeout=1.000000, bRemoveAfter=True)
		
	
		# Resume debugger.
		self._resumeDebugger()
	
		#=============
		# RESET BOARD
		#=============
		self._resetBoard()
	
		#========================
		# CHECK EXPECTED RESULTS
		#========================
		# Wait for Breakpoint SafeM_Init to be exited
		self._waitDebuggerExitedBreakpoint(breakpoint="SafeM_Init")
		
		# Breakpoint SafeM_StartErrorOutToggling reached exactly 1 time
		self._assertBreakpointReachedExactly(breakpoint="SafeM_StartErrorOutToggling", assertCount=1)
		
		# Breakpoint SafeM_Init reached before SafeM_StartErrorOutToggling
		self._assertBreakpointReachedBefore(breakpoint1="SafeM_Init", breakpoint2="SafeM_StartErrorOutToggling")
	
	
	
	
	#===============
	# POSTCONDITION
	#===============
	def tearDown(self):
	
		#==========================================
		# 01. Unset BP SafeM_StartErrorOutToggling
		#==========================================
		self.executeStep(ID="SPEC_SafeMng_FCT_22", fct=self.__step3_1, step=1, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03")
		
		
		
		#=========================
		# 02. Unset BP SafeM_Init
		#=========================
		self.executeStep(ID="SPEC_SafeMng_FCT_27", fct=self.__step3_2, step=2, breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03")
		
		
		
	
	def __step3_1(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_22
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_StartErrorOutToggling(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_03.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#==================
		# UNSET BREAKPOINT
		#==================
		self._removeBreakpoint(breakpoint="SafeM_StartErrorOutToggling")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	def __step3_2(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_27
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_Init(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_01_Test_Case_03.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#==================
		# UNSET BREAKPOINT
		#==================
		self._removeBreakpoint(breakpoint="SafeM_Init")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_01_Test_Case_03.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	
