# Test Autotool Generator v1.1.0
from test.framework.generic.suite import TestSuiteGeneric

from Functional_Tests.Test_Suite_01.Test_Case_01.case import Test_Case_01
from Functional_Tests.Test_Suite_01.Test_Case_02.case import Test_Case_02
from Functional_Tests.Test_Suite_01.Test_Case_03.case import Test_Case_03

class Test_Suite_01(TestSuiteGeneric):
	"""
	@requirement SPEC_SafeMng_FCT_2
	"""

	def __init__(self, rootBreakpoint, debuggerWindow, debuggerHandle, debugServer):

		# Call parent's constructor.
		TestSuiteGeneric.__init__(self, ID="SPEC_SafeMng_FCT_2", rootBreakpoint=rootBreakpoint, debuggerWindow=debuggerWindow, debuggerHandle=debuggerHandle, debugServer=debugServer)

		self._addCase(ID="SPEC_SafeMng_FCT_3", index=1, testCase=Test_Case_01)
		self._addCase(ID="SPEC_SafeMng_FCT_11", index=2, testCase=Test_Case_02)
		self._addCase(ID="SPEC_SafeMng_FCT_18", index=3, testCase=Test_Case_03)
