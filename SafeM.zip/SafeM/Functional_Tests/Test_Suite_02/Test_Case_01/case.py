# Test Autotool Generator v1.1.0


import time
import random

from test.framework.generic.case import TestCaseGeneric

from test.framework.generic.type import *
from test.manager import setCurrentStep

class Test_Case_01(TestCaseGeneric): 
	"""
	@requirement SPEC_SafeMng_FCT_30
	"""

	
	#=============
	# DECLARATION
	#=============
	
	
	#=============
	# ORIGIN STEP
	#=============
	def getOriginStepList(self):
		"""
		@return List of steps that originate from this TestCase (neither a Reference nor a Template).
		"""
		return ['SPEC_SafeMng_FCT_34', 'SPEC_SafeMng_FCT_37', 'SPEC_SafeMng_FCT_38', 'SPEC_SafeMng_FCT_39', 'SPEC_SafeMng_FCT_40', 'SPEC_SafeMng_FCT_41', 'SPEC_SafeMng_FCT_36']
	
	
	#==============
	# PRECONDITION
	#==============
	def setUp(self):
	
		#===============================
		# 01. Set BP SafeM_SetSafeState
		#===============================
		self.executeStep(ID="SPEC_SafeMng_FCT_34", fct=self.__step1_1, step=1, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01")
		
		
		
	
	def __step1_1(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_34
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_SetSafeState(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_02_Test_Case_01.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#================
		# SET BREAKPOINT
		#================
		self._setBreakpoint(breakpoint="SafeM_SetSafeState")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	
	
	#======
	# TEST
	#======
	def runTest(self):
	
		#==================
		# 01. Reset board 
		#==================
		self.executeStep(ID="SPEC_SafeMng_FCT_37", fct=self.__step2_1, step=1, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01")
		
		
		
		#===============
		# 02. Sleep 1.0
		#===============
		self.executeStep(ID="SPEC_SafeMng_FCT_38", fct=self.__step2_2, step=None, breakpoint=None)
		
		
		
		#===========================================
		# 03. Code Com_RxSigBufferXInt8.raw[34] = 1
		#===========================================
		self.executeStep(ID="SPEC_SafeMng_FCT_39", fct=self.__step2_3, step=3, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01")
		
		
		
		#===============
		# 04. Sleep 1.0
		#===============
		self.executeStep(ID="SPEC_SafeMng_FCT_40", fct=self.__step2_4, step=None, breakpoint=None)
		
		
		
		#===========================================
		# 05. Code Com_RxSigBufferXInt8.raw[34] = 0
		#===========================================
		self.executeStep(ID="SPEC_SafeMng_FCT_41", fct=self.__step2_5, step=5, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01")
		
		
		
	
	def __step2_1(self):
		"""
		@requirement SPEC_SafeMng_FCT_37
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01", timeout=1.000000, bRemoveAfter=True)
		
	
		# Resume debugger.
		self._resumeDebugger()
	
		#=============
		# RESET BOARD
		#=============
		self._resetBoard()
	
	
	def __step2_2(self):
		"""
		@requirement SPEC_SafeMng_FCT_38
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
	
		#=======
		# SLEEP
		#=======
		self._sleep(timeoutS=1.0)
	
	
	def __step2_3(self):
		"""
		@brief Set ComKL15 CAN signal to 1.
		       Com_RxSigBufferXInt8.raw[34] = 1
		@requirement SPEC_SafeMng_FCT_39
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01", timeout=1.000000, bRemoveAfter=True)
		
	
	
		#==============
		# EXECUTE CODE
		#==============
		# Com_RxSigBufferXInt8.raw[34] = 1
		self._executeCode(cmd="Com_RxSigBufferXInt8.raw[34] = 1")
	
	
	def __step2_4(self):
		"""
		@brief Wait for Com_Ignition CAN frame confirmation.
		       State Manager is in EPS_IDLE state.
		@requirement SPEC_SafeMng_FCT_40
		"""
	
		# List of conditions verified by this step.
		lCondition = ['StateM_State_t == EPS_IDLE']
		self.setConditionListForCurrentStep(lCondition)
	
	
		#=======
		# SLEEP
		#=======
		self._sleep(timeoutS=1.0)
	
		#========================
		# CHECK EXPECTED RESULTS
		#========================
		# StateM_State_t == EPS_IDLE
		self._assertExpression("StateM_State_t == 1")
	
	
	def __step2_5(self):
		"""
		@brief Set ComKL15 CAN signal to 0.
		       Com_RxSigBufferXInt8.raw[34] = 0
		       Simulate a Communication error.
		       StateM treats this Communication error as a failure and goes into EPS_SAFE_ASSIST state.
		       Check that StateM notifies SafeM.
		@requirement SPEC_SafeMng_FCT_41
		"""
	
		# List of conditions verified by this step.
		lCondition = ['Wait for Breakpoint SafeM_SetSafeState to be exited', 'StateM_State_t == EPS_SAFE_ASSIST']
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01", timeout=1.000000, bRemoveAfter=True)
		
	
	
		#==============
		# EXECUTE CODE
		#==============
		# Com_RxSigBufferXInt8.raw[34] = 0
		self._executeCode(cmd="Com_RxSigBufferXInt8.raw[34] = 0")
	
		#========================
		# CHECK EXPECTED RESULTS
		#========================
		# Wait for Breakpoint SafeM_SetSafeState to be exited
		self._waitDebuggerExitedBreakpoint(breakpoint="SafeM_SetSafeState")
		
		# StateM_State_t == EPS_SAFE_ASSIST
		self._assertExpression("StateM_State_t == 8")
	
	
	
	
	#===============
	# POSTCONDITION
	#===============
	def tearDown(self):
	
		#=================================
		# 01. Unset BP SafeM_SetSafeState
		#=================================
		self.executeStep(ID="SPEC_SafeMng_FCT_36", fct=self.__step3_1, step=1, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01")
		
		
		
	
	def __step3_1(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_36
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_SetSafeState(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_02_Test_Case_01.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#==================
		# UNSET BREAKPOINT
		#==================
		self._removeBreakpoint(breakpoint="SafeM_SetSafeState")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_01.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	
