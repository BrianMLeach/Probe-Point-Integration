#include "Rte_Type.h"
#include "test_mechanism.h"

#include "Functional_Tests_Test_Suite_02.h"
#include "Functional_Tests_Test_Suite_02_Test_Case_01.h"
#include "Functional_Tests_Test_Suite_02_Test_Case_02.h"

FUNC(void, CtAppSwc_Debug_CODE) Functional_Tests_Test_Suite_02(void)
{
	switch(ui8CurrentCase)
	{
	case 1:
		Functional_Tests_Test_Suite_02_Test_Case_01();
		break;
	case 2:
		Functional_Tests_Test_Suite_02_Test_Case_02();
		break;
	}

}
