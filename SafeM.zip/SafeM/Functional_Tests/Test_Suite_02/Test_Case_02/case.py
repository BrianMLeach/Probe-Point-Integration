# Test Autotool Generator v1.1.0


import time
import random

from test.framework.generic.case import TestCaseGeneric

from test.framework.generic.type import *
from test.manager import setCurrentStep

class Test_Case_02(TestCaseGeneric): 
	"""
	@requirement SPEC_SafeMng_FCT_46
	"""

	
	#=============
	# DECLARATION
	#=============
	
	
	#=============
	# ORIGIN STEP
	#=============
	def getOriginStepList(self):
		"""
		@return List of steps that originate from this TestCase (neither a Reference nor a Template).
		"""
		return ['SPEC_SafeMng_FCT_47', 'SPEC_SafeMng_FCT_70', 'SPEC_SafeMng_FCT_68', 'SPEC_SafeMng_FCT_48', 'SPEC_SafeMng_FCT_49', 'SPEC_SafeMng_FCT_50', 'SPEC_SafeMng_FCT_51', 'SPEC_SafeMng_FCT_52', 'SPEC_SafeMng_FCT_59', 'SPEC_SafeMng_FCT_60', 'SPEC_SafeMng_FCT_61', 'SPEC_SafeMng_FCT_62', 'SPEC_SafeMng_FCT_53', 'SPEC_SafeMng_FCT_71', 'SPEC_SafeMng_FCT_69']
	
	
	#==============
	# PRECONDITION
	#==============
	def setUp(self):
	
		#===============================
		# 01. Set BP SafeM_SetSafeState
		#===============================
		self.executeStep(ID="SPEC_SafeMng_FCT_47", fct=self.__step1_1, step=1, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
		#===================================
		# 02. Set BP SafeM_SetShutdownState
		#===================================
		self.executeStep(ID="SPEC_SafeMng_FCT_70", fct=self.__step1_2, step=2, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
		#======================================================
		# 03. Set BP BswM_ActionList_EPSPP_AL_RunToPreShutdown
		#======================================================
		self.executeStep(ID="SPEC_SafeMng_FCT_68", fct=self.__step1_3, step=3, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
	
	def __step1_1(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_47
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_SetSafeState(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#================
		# SET BREAKPOINT
		#================
		self._setBreakpoint(breakpoint="SafeM_SetSafeState")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	def __step1_2(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_70
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_SetShutdownState(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#================
		# SET BREAKPOINT
		#================
		self._setBreakpoint(breakpoint="SafeM_SetShutdownState")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	def __step1_3(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_68
		Prototype of the function is defined as follows:
		STATIC FUNC(Std_ReturnType, BSWM_CODE) BswM_ActionList_EPSPP_AL_RunToPreShutdown(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#================
		# SET BREAKPOINT
		#================
		self._setBreakpoint(breakpoint="BswM_ActionList_EPSPP_AL_RunToPreShutdown")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	
	
	#======
	# TEST
	#======
	def runTest(self):
	
		#==================
		# 01. Reset board 
		#==================
		self.executeStep(ID="SPEC_SafeMng_FCT_48", fct=self.__step2_1, step=1, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
		#===============
		# 02. Sleep 1.0
		#===============
		self.executeStep(ID="SPEC_SafeMng_FCT_49", fct=self.__step2_2, step=None, breakpoint=None)
		
		
		
		#===========================================
		# 03. Code Com_RxSigBufferXInt8.raw[34] = 1
		#===========================================
		self.executeStep(ID="SPEC_SafeMng_FCT_50", fct=self.__step2_3, step=3, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
		#===============
		# 04. Sleep 1.0
		#===============
		self.executeStep(ID="SPEC_SafeMng_FCT_51", fct=self.__step2_4, step=None, breakpoint=None)
		
		
		
		#===========================================
		# 05. Code Com_RxSigBufferXInt8.raw[82] = 1
		#===========================================
		self.executeStep(ID="SPEC_SafeMng_FCT_52", fct=self.__step2_5, step=5, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
		#===============
		# 06. Sleep 1.0
		#===============
		self.executeStep(ID="SPEC_SafeMng_FCT_59", fct=self.__step2_6, step=None, breakpoint=None)
		
		
		
		#====================================
		# 07. Manual PMIC KL15 switch to OFF
		#====================================
		self.executeStep(ID="SPEC_SafeMng_FCT_60", fct=self.__step2_7, step=7, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
		#================
		# 08. Sleep 30.0
		#================
		self.executeStep(ID="SPEC_SafeMng_FCT_61", fct=self.__step2_8, step=None, breakpoint=None)
		
		
		
		#===================================
		# 09. Manual PMIC KL15 switch to ON
		#===================================
		self.executeStep(ID="SPEC_SafeMng_FCT_62", fct=self.__step2_9, step=9, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
	
	def __step2_1(self):
		"""
		@requirement SPEC_SafeMng_FCT_48
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		# Resume debugger.
		self._resumeDebugger()
	
		#=============
		# RESET BOARD
		#=============
		self._resetBoard()
	
	
	def __step2_2(self):
		"""
		@requirement SPEC_SafeMng_FCT_49
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
	
		#=======
		# SLEEP
		#=======
		self._sleep(timeoutS=1.0)
	
	
	def __step2_3(self):
		"""
		@brief Set ComKL15 CAN signal to 1.
		       Com_RxSigBufferXInt8.raw[34] = 1
		@requirement SPEC_SafeMng_FCT_50
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
	
		#==============
		# EXECUTE CODE
		#==============
		# Com_RxSigBufferXInt8.raw[34] = 1
		self._executeCode(cmd="Com_RxSigBufferXInt8.raw[34] = 1")
	
	
	def __step2_4(self):
		"""
		@brief Wait for Com_Ignition CAN frame confirmation.
		@requirement SPEC_SafeMng_FCT_51
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
	
		#=======
		# SLEEP
		#=======
		self._sleep(timeoutS=1.0)
	
	
	def __step2_5(self):
		"""
		@brief Set EngState CAN signal to 1.
		       Com_RxSigBufferXInt8.raw[82] = 1
		@requirement SPEC_SafeMng_FCT_52
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
	
		#==============
		# EXECUTE CODE
		#==============
		# Com_RxSigBufferXInt8.raw[82] = 1
		self._executeCode(cmd="Com_RxSigBufferXInt8.raw[82] = 1")
	
	
	def __step2_6(self):
		"""
		@brief State Manager is in EPS_RUN state.
		@requirement SPEC_SafeMng_FCT_59
		"""
	
		# List of conditions verified by this step.
		lCondition = ['StateM_State_t == EPS_RUN']
		self.setConditionListForCurrentStep(lCondition)
	
	
		#=======
		# SLEEP
		#=======
		self._sleep(timeoutS=1.0)
	
		#========================
		# CHECK EXPECTED RESULTS
		#========================
		# StateM_State_t == EPS_RUN
		self._assertExpression("StateM_State_t == 3")
	
	
	def __step2_7(self):
		"""
		@brief Switch off KL15 signal coming from PMIC device.
		       Check that StateM has requested a ECU shutdown and BswM has triggered the Action List to go from BSWM_ECUM_RUN to BSWM_ECUM_PRESHUTDOWN state.
		       Check that StateM current state is EPS_SHUTDOWN.
		       Check that StateM does not notify SafeM about entering in Safe state.
		       Check that BswM notifies SafeM about entering in Safe state during the Shutdown phase.
		@requirement SPEC_SafeMng_FCT_60
		"""
	
		# List of conditions verified by this step.
		lCondition = ['Wait for Breakpoint BswM_ActionList_EPSPP_AL_RunToPreShutdown to be exited', 'Breakpoint SafeM_SetShutdownState reached exactly 1 time']
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
	
		#=====================
		# MANUAL INTERVENTION
		#=====================
		self._waitManualIntervention(msg="PMIC KL15 switch to OFF")
	
		#========================
		# CHECK EXPECTED RESULTS
		#========================
		# Wait for Breakpoint BswM_ActionList_EPSPP_AL_RunToPreShutdown to be exited
		self._waitDebuggerExitedBreakpoint(breakpoint="BswM_ActionList_EPSPP_AL_RunToPreShutdown")
		
		# Breakpoint SafeM_SetShutdownState reached exactly 1 time
		self._assertBreakpointReachedExactly(breakpoint="SafeM_SetShutdownState", assertCount=1)
	
	
	def __step2_8(self):
		"""
		@requirement SPEC_SafeMng_FCT_61
		"""
	
		# List of conditions verified by this step.
		lCondition = ['BswM_GenericState[0] == BSWM_GENERICVALUE_ECUM_State_BSWM_ECUM_PRESHUTDOWN', 'Breakpoint SafeM_SetSafeState reached exactly 1 time', 'Breakpoint BswM_ActionList_EPSPP_AL_RunToPreShutdown reached before SafeM_SetSafeState', 'Breakpoint BswM_ActionList_EPSPP_AL_RunToPreShutdown reached before SafeM_SetShutdownState', 'Breakpoint SafeM_SetShutdownState reached before SafeM_SetSafeState', 'StateM_State_t == EPS_SHUTDOWN']
		self.setConditionListForCurrentStep(lCondition)
	
	
		#=======
		# SLEEP
		#=======
		self._sleep(timeoutS=30.0)
	
		#========================
		# CHECK EXPECTED RESULTS
		#========================
		# BswM_GenericState[0] == BSWM_GENERICVALUE_ECUM_State_BSWM_ECUM_PRESHUTDOWN
		self._assertExpression("BswM_GenericState[0] == 0x0003")
		
		# Breakpoint SafeM_SetSafeState reached exactly 1 time
		self._assertBreakpointReachedExactly(breakpoint="SafeM_SetSafeState", assertCount=1)
		
		# Breakpoint BswM_ActionList_EPSPP_AL_RunToPreShutdown reached before SafeM_SetSafeState
		self._assertBreakpointReachedBefore(breakpoint1="BswM_ActionList_EPSPP_AL_RunToPreShutdown", breakpoint2="SafeM_SetSafeState")
		
		# Breakpoint BswM_ActionList_EPSPP_AL_RunToPreShutdown reached before SafeM_SetShutdownState
		self._assertBreakpointReachedBefore(breakpoint1="BswM_ActionList_EPSPP_AL_RunToPreShutdown", breakpoint2="SafeM_SetShutdownState")
		
		# Breakpoint SafeM_SetShutdownState reached before SafeM_SetSafeState
		self._assertBreakpointReachedBefore(breakpoint1="SafeM_SetShutdownState", breakpoint2="SafeM_SetSafeState")
		
		# StateM_State_t == EPS_SHUTDOWN
		self._assertExpression("StateM_State_t == 9")
	
	
	def __step2_9(self):
		"""
		@requirement SPEC_SafeMng_FCT_62
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
	
		#=====================
		# MANUAL INTERVENTION
		#=====================
		self._waitManualIntervention(msg="PMIC KL15 switch to ON")
	
	
	
	
	#===============
	# POSTCONDITION
	#===============
	def tearDown(self):
	
		#========================================================
		# 01. Unset BP BswM_ActionList_EPSPP_AL_RunToPreShutdown
		#========================================================
		self.executeStep(ID="SPEC_SafeMng_FCT_53", fct=self.__step3_1, step=1, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
		#=====================================
		# 02. Unset BP SafeM_SetShutdownState
		#=====================================
		self.executeStep(ID="SPEC_SafeMng_FCT_71", fct=self.__step3_2, step=2, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
		#=================================
		# 03. Unset BP SafeM_SetSafeState
		#=================================
		self.executeStep(ID="SPEC_SafeMng_FCT_69", fct=self.__step3_3, step=3, breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02")
		
		
		
	
	def __step3_1(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_53
		Prototype of the function is defined as follows:
		STATIC FUNC(Std_ReturnType, BSWM_CODE) BswM_ActionList_EPSPP_AL_RunToPreShutdown(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#==================
		# UNSET BREAKPOINT
		#==================
		self._removeBreakpoint(breakpoint="BswM_ActionList_EPSPP_AL_RunToPreShutdown")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	def __step3_2(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_71
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_SetShutdownState(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#==================
		# UNSET BREAKPOINT
		#==================
		self._removeBreakpoint(breakpoint="SafeM_SetShutdownState")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	def __step3_3(self):
		"""
		@brief N/A
		@requirement SPEC_SafeMng_FCT_69
		Prototype of the function is defined as follows:
		extern FUNC(void,SAFEM_PUBLIC_CODE) SafeM_SetSafeState(void);
		"""
	
		# List of conditions verified by this step.
		lCondition = []
		self.setConditionListForCurrentStep(lCondition)
	
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02", timeout=1.000000, bRemoveAfter=True)
		
	
		self._setBreakpoint("Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished")
		# Resume debugger.
		self._resumeDebugger()
	
		#==================
		# UNSET BREAKPOINT
		#==================
		self._removeBreakpoint(breakpoint="SafeM_SetSafeState")
	
		# Break debugger on current Test Case.
		self._waitDebuggerReachedBreakpoint(breakpoint="Functional_Tests_Test_Suite_02_Test_Case_02.c#Test_StepFinished", timeout=1.000000, bRemoveAfter=True)
		
	
	
	
