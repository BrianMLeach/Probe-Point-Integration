# Test Autotool Generator v1.1.0
from test.framework.generic.suite import TestSuiteGeneric

from Functional_Tests.Test_Suite_02.Test_Case_01.case import Test_Case_01
from Functional_Tests.Test_Suite_02.Test_Case_02.case import Test_Case_02

class Test_Suite_02(TestSuiteGeneric):
	"""
	@requirement SPEC_SafeMng_FCT_28
	"""

	def __init__(self, rootBreakpoint, debuggerWindow, debuggerHandle, debugServer):

		# Call parent's constructor.
		TestSuiteGeneric.__init__(self, ID="SPEC_SafeMng_FCT_28", rootBreakpoint=rootBreakpoint, debuggerWindow=debuggerWindow, debuggerHandle=debuggerHandle, debugServer=debugServer)

		self._addCase(ID="SPEC_SafeMng_FCT_30", index=1, testCase=Test_Case_01)
		self._addCase(ID="SPEC_SafeMng_FCT_46", index=2, testCase=Test_Case_02)
