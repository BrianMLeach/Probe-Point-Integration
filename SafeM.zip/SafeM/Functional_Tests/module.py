# Test Autotool Generator v1.1.0
from test.framework.generic.suite import TestSuiteGeneric

from test.manager import setCurrentSuite

from Functional_Tests.Test_Suite_01.suite import Test_Suite_01
from Functional_Tests.Test_Suite_02.suite import Test_Suite_02

class Functional_Tests(TestSuiteGeneric):
	"""
	@requirement SPEC_SafeMng_FCT_1
	"""

	def __init__(self, rootBreakpoint, debuggerWindow, debuggerHandle, debugServer):

		# Call parent's constructor.
		TestSuiteGeneric.__init__(self, ID="SPEC_SafeMng_FCT_1", rootBreakpoint=rootBreakpoint, debuggerWindow=debuggerWindow, debuggerHandle=debuggerHandle, debugServer=debugServer)

		self._addSuite(index=1, testSuite=Test_Suite_01)
		self._addSuite(index=2, testSuite=Test_Suite_02)
