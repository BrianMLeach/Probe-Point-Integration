#include "Rte_Type.h"
#include "test_mechanism.h"
#include "Functional_Tests_Test_Suite_01.h"
#include "Functional_Tests_Test_Suite_02.h"

/*===============================*/
/* Testing mechanism declaration */
/*===============================*/
volatile VAR(uint16, AppSwc_Debug_VAR_INIT) ui16CurrentSuite = 0;
volatile VAR(uint8, AppSwc_Debug_VAR_INIT) ui8CurrentCase = 0;
volatile VAR(uint8, AppSwc_Debug_VAR_INIT) ui8CurrentSequence = 0;
volatile VAR(uint8, AppSwc_Debug_VAR_INIT) ui8CurrentStep = 0;
volatile VAR(uint16, AppSwc_Debug_VAR_INIT) ui16CurrentDelayStep = 0;

FUNC(void, CtAppSwc_Debug_CODE) R_AppSwc_Functional_Tests_Debug(void)
{

	switch(ui16CurrentSuite)
	{
	case 1:
		Functional_Tests_Test_Suite_01();
		break;
	case 2:
		Functional_Tests_Test_Suite_02();
		break;
	}

}
