#ifndef FUNCTIONAL_TESTS_TEST_SUITE_05_TEST_CASE_02_H
#define FUNCTIONAL_TESTS_TEST_SUITE_05_TEST_CASE_02_H

#include "Rte_Type.h"

FUNC(void, CtAppSwc_Debug_CODE) Functional_Tests_Test_Suite_05_Test_Case_02(void);
#endif