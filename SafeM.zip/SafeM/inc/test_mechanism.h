#include "Std_Types.h"

extern volatile VAR(uint16, AppSwc_Debug_VAR_INIT) ui16CurrentSuite;
extern volatile VAR(uint8, AppSwc_Debug_VAR_INIT) ui8CurrentCase;
extern volatile VAR(uint8, AppSwc_Debug_VAR_INIT) ui8CurrentSequence;
extern volatile VAR(uint8, AppSwc_Debug_VAR_INIT) ui8CurrentStep;

extern volatile VAR(uint16, AppSwc_Debug_VAR_INIT) ui16CurrentDelayStep;