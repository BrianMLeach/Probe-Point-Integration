#ifndef FUNCTIONAL_TESTS_TEST_SUITE_06_TEST_CASE_03_H
#define FUNCTIONAL_TESTS_TEST_SUITE_06_TEST_CASE_03_H

#include "Rte_Type.h"

FUNC(void, CtAppSwc_Debug_CODE) Functional_Tests_Test_Suite_06_Test_Case_03(void);
#endif